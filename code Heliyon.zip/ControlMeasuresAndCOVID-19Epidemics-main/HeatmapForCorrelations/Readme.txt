# heatmap.m
Main file. Heatmap for correlations among control measures of 127 countries/territories. Strong positive correlations are indicated by dark red, and weak correlations by dark blue

# Requirements
The code is implemented in MATLAB R2021b.