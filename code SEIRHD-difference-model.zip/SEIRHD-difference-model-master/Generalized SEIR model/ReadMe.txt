1. Description:This program is about parameter identification of SEIRHD model by using simulated annealing method and fit incubated population,healed population and death number.
*Note that you should load data in the form of date,identified number,healed number,death number.
2. Operation instructions: Run main_SEIR.m and select the TXT file, after searching parameter space for a few minutes then parameters and fit results come out.
(Multiple runs required and you can get the optimal parameters)
3. File description:  main_SEIR.m-- main file
	               SEIR.m--SEIR model
	               fit.m--plot the result of fitting and prediction
