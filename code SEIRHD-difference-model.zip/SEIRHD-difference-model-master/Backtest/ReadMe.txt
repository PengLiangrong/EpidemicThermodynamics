1. Description:This program is about backtracking of epidemic situation.According to the initial value(E+I+R)of the 1.20, backtest how many E,I,R before this.The parameters(alpha,beta,delta etc.) were set accroding to Table 1
2. Operation instructions: Run Backtest.m, after searching parameter space for a few minutes then parameters and fit results come out.
(Multiple runs required and you can get the optimal parameters)
3. File description:  Backtest.m-- main file
	               EIR.m--EIR model

